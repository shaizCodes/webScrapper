import java.awt.Color;
import java.util.ArrayList;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JProgressBar;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicProgressBarUI;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebScrapper extends javax.swing.JFrame {
    public static String baseURL = "";
    private ArrayList<Category> categories = new ArrayList<Category>();
    
    public WebScrapper() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        webURLTextField = new javax.swing.JTextField();
        scrapButton = new javax.swing.JButton();
        storyComboBox = new javax.swing.JComboBox<>();
        categoryComboBox = new javax.swing.JComboBox<>();
        resultsTab = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        totalUniqueWordsField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        totalWordsField = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        highestWordFrequencyField = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        frequencyValue1 = new javax.swing.JProgressBar();
        frequencyValue2 = new javax.swing.JProgressBar();
        frequencyValue3 = new javax.swing.JProgressBar();
        frequencyValue4 = new javax.swing.JProgressBar();
        frequencyValue5 = new javax.swing.JProgressBar();
        frequencyValue6 = new javax.swing.JProgressBar();
        frequencyValue7 = new javax.swing.JProgressBar();
        frequencyValue8 = new javax.swing.JProgressBar();
        frequencyValue9 = new javax.swing.JProgressBar();
        frequencyValue10 = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Website URL");

        webURLTextField.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        webURLTextField.setText("https://www.bbc.com/urdu");
        webURLTextField.setEnabled(false);
        webURLTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                webURLTextFieldActionPerformed(evt);
            }
        });

        scrapButton.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        scrapButton.setText("SCRAP");
        scrapButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scrapButtonActionPerformed(evt);
            }
        });

        storyComboBox.setFont(new java.awt.Font("Simplified Arabic Fixed", 0, 18)); // NOI18N
        storyComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Story" }));
        storyComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                storyComboBoxActionPerformed(evt);
            }
        });

        categoryComboBox.setFont(new java.awt.Font("Simplified Arabic Fixed", 0, 18)); // NOI18N
        categoryComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Category" }));
        categoryComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                categoryComboBoxActionPerformed(evt);
            }
        });

        resultsTab.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        resultsTab.setFont(new java.awt.Font("Tempus Sans ITC", 1, 12)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("Total Words: ");

        totalUniqueWordsField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        totalUniqueWordsField.setText("0");
        totalUniqueWordsField.setEnabled(false);
        totalUniqueWordsField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalUniqueWordsFieldActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Total Unique Words:");

        totalWordsField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        totalWordsField.setText("0");
        totalWordsField.setEnabled(false);
        totalWordsField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalWordsFieldActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Highest Word Frequency:");

        highestWordFrequencyField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        highestWordFrequencyField.setText("0");
        highestWordFrequencyField.setEnabled(false);
        highestWordFrequencyField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                highestWordFrequencyFieldActionPerformed(evt);
            }
        });

        frequencyValue1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue1.setMaximum(150);
        frequencyValue1.setToolTipText("");
        frequencyValue1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue1.setEnabled(false);
        frequencyValue1.setFocusable(false);
        frequencyValue1.setOpaque(true);
        frequencyValue1.setRequestFocusEnabled(false);
        frequencyValue1.setString("");
        frequencyValue1.setStringPainted(true);
        frequencyValue1.setVerifyInputWhenFocusTarget(false);

        frequencyValue2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue2.setMaximum(150);
        frequencyValue2.setToolTipText("");
        frequencyValue2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue2.setEnabled(false);
        frequencyValue2.setFocusable(false);
        frequencyValue2.setOpaque(true);
        frequencyValue2.setRequestFocusEnabled(false);
        frequencyValue2.setString("");
        frequencyValue2.setStringPainted(true);
        frequencyValue2.setVerifyInputWhenFocusTarget(false);

        frequencyValue3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue3.setMaximum(150);
        frequencyValue3.setToolTipText("");
        frequencyValue3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue3.setEnabled(false);
        frequencyValue3.setFocusable(false);
        frequencyValue3.setOpaque(true);
        frequencyValue3.setRequestFocusEnabled(false);
        frequencyValue3.setString("");
        frequencyValue3.setStringPainted(true);
        frequencyValue3.setVerifyInputWhenFocusTarget(false);

        frequencyValue4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue4.setMaximum(150);
        frequencyValue4.setToolTipText("");
        frequencyValue4.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue4.setEnabled(false);
        frequencyValue4.setFocusable(false);
        frequencyValue4.setOpaque(true);
        frequencyValue4.setRequestFocusEnabled(false);
        frequencyValue4.setString("");
        frequencyValue4.setStringPainted(true);
        frequencyValue4.setVerifyInputWhenFocusTarget(false);

        frequencyValue5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue5.setMaximum(150);
        frequencyValue5.setToolTipText("");
        frequencyValue5.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue5.setEnabled(false);
        frequencyValue5.setFocusable(false);
        frequencyValue5.setOpaque(true);
        frequencyValue5.setRequestFocusEnabled(false);
        frequencyValue5.setString("");
        frequencyValue5.setStringPainted(true);
        frequencyValue5.setVerifyInputWhenFocusTarget(false);

        frequencyValue6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue6.setMaximum(150);
        frequencyValue6.setToolTipText("");
        frequencyValue6.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue6.setEnabled(false);
        frequencyValue6.setFocusable(false);
        frequencyValue6.setOpaque(true);
        frequencyValue6.setRequestFocusEnabled(false);
        frequencyValue6.setString("");
        frequencyValue6.setStringPainted(true);
        frequencyValue6.setVerifyInputWhenFocusTarget(false);

        frequencyValue7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue7.setMaximum(150);
        frequencyValue7.setToolTipText("");
        frequencyValue7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue7.setEnabled(false);
        frequencyValue7.setFocusable(false);
        frequencyValue7.setOpaque(true);
        frequencyValue7.setRequestFocusEnabled(false);
        frequencyValue7.setString("");
        frequencyValue7.setStringPainted(true);
        frequencyValue7.setVerifyInputWhenFocusTarget(false);

        frequencyValue8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue8.setMaximum(150);
        frequencyValue8.setToolTipText("");
        frequencyValue8.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue8.setEnabled(false);
        frequencyValue8.setFocusable(false);
        frequencyValue8.setOpaque(true);
        frequencyValue8.setRequestFocusEnabled(false);
        frequencyValue8.setString("");
        frequencyValue8.setStringPainted(true);
        frequencyValue8.setVerifyInputWhenFocusTarget(false);

        frequencyValue9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue9.setMaximum(150);
        frequencyValue9.setToolTipText("");
        frequencyValue9.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue9.setEnabled(false);
        frequencyValue9.setFocusable(false);
        frequencyValue9.setOpaque(true);
        frequencyValue9.setRequestFocusEnabled(false);
        frequencyValue9.setString("");
        frequencyValue9.setStringPainted(true);
        frequencyValue9.setVerifyInputWhenFocusTarget(false);

        frequencyValue10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        frequencyValue10.setMaximum(150);
        frequencyValue10.setToolTipText("");
        frequencyValue10.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        frequencyValue10.setEnabled(false);
        frequencyValue10.setFocusable(false);
        frequencyValue10.setOpaque(true);
        frequencyValue10.setRequestFocusEnabled(false);
        frequencyValue10.setString("");
        frequencyValue10.setStringPainted(true);
        frequencyValue10.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(frequencyValue1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(frequencyValue2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(frequencyValue3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(frequencyValue4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(frequencyValue5, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(frequencyValue6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(frequencyValue7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(frequencyValue8, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(frequencyValue9, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(frequencyValue10, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(frequencyValue1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(frequencyValue2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(frequencyValue3, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(frequencyValue4, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(frequencyValue5, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(frequencyValue6, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(frequencyValue7, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(frequencyValue8, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(frequencyValue9, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(frequencyValue10, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(totalWordsField, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(totalUniqueWordsField, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(highestWordFrequencyField, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(182, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(totalWordsField, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(totalUniqueWordsField, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(highestWordFrequencyField, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(96, 96, 96))
        );

        resultsTab.addTab("Results1", jPanel2);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(resultsTab)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(categoryComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(storyComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(webURLTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 602, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(scrapButton, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(scrapButton, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE))
                    .addComponent(webURLTextField)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(storyComboBox, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                    .addComponent(categoryComboBox))
                .addGap(18, 18, 18)
                .addComponent(resultsTab, javax.swing.GroupLayout.PREFERRED_SIZE, 354, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void scrapButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scrapButtonActionPerformed
        baseURL = webURLTextField.getText();
        if(baseURL.length() == 0){
            baseURL = "https://www.bbc.com/urdu";
        }
        Document indexPage = null;
        try {
            indexPage = Jsoup.connect(baseURL).timeout(0).get();
        } catch (IOException ex) {
            Logger.getLogger(WebScrapper.class.getName()).log(Level.SEVERE, null, ex);
        }
        //SELECTING LIST OF CATEGORIES
        Elements listItems = indexPage.getElementsByClass("bbc-1v9wiw8 e1ibkbh72");
        int n=0;
        for(Element element : listItems){
            n++;
            if(n>1 && n<7){
                categories.add(openCategory(element));
                System.out.println("added a new category...");
            }
            else{
                break;
            }
        }
        String[] categoryNames = new String[categories.toArray().length+1];
        String[] storyNames = null;
        int i=0;
        categoryNames[i++] = "Select Category";   
        System.out.println("After select category...");
        for(Object object: categories.toArray()){
            categoryNames[(i++)] = ((Category)object).getName();
        }
        System.out.println("Categories: "+categoryNames.length);
        categoryComboBox.setModel(new DefaultComboBoxModel(categoryNames));
    }//GEN-LAST:event_scrapButtonActionPerformed

    private Category openCategory(Element element){
        Category category = new Category(element.child(0).text(), element.child(0).attr("href"));
        int pageNumber = 1;
        try {
            Document categoryPage = Jsoup.connect(baseURL.replaceAll("/urdu", category.getURL())).get();
            visitStoryList(categoryPage, pageNumber, category);
        } catch (IOException ex) {
            Logger.getLogger(WebScrapper.class.getName()).log(Level.SEVERE, null, ex);
        }
        return category;
    }

    private void visitStoryList(Document categoryPage, int pageNumber, Category category) throws IOException{
        Elements stories = categoryPage.getElementsByClass("bbc-uk8dsi emimjbx0");
        for (Element story : stories) {
            category.addStory(new Story(story.text(), story.attr("href")));
            if(category.getTotalStoryCount() == 100){
                return;
            }
        }
        categoryPage = Jsoup.connect(baseURL.replaceAll("/urdu", category.getURL()+"?page="+(++pageNumber))).get();
        visitStoryList(categoryPage, pageNumber, category);
    }

    private void storyComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_storyComboBoxActionPerformed
        Story theStory = null;
        if(categoryComboBox.getSelectedIndex()==0 || storyComboBox.getSelectedIndex()==0){
            return;
        }
        if(categoryComboBox.getSelectedIndex()!=0 && storyComboBox.getSelectedIndex()<3){
            for (Story story : categories.get(categoryComboBox.getSelectedIndex()-1).getStories()) {
                try {
                    String storyContent = "";
                    Elements paragraphs = Jsoup.connect(story.getURL()).get().getElementsByClass("bbc-yabuuk e1cc2ql70");
                    for (Element paragraph : paragraphs) {
                        storyContent += paragraph.text();
                    }
                    story.addContent(storyContent);
                } catch (IOException ex) {
                    Logger.getLogger(WebScrapper.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            int index = storyComboBox.getSelectedIndex();
            theStory = (index==1 ? (categories.get(categoryComboBox.getSelectedIndex()-1).getMinStory()) : (categories.get(categoryComboBox.getSelectedIndex()-1).getMaxStory()));
        }
        else{
            theStory = categories.get(categoryComboBox.getSelectedIndex()-1).getStories().get(storyComboBox.getSelectedIndex()-3);
        }
        String storyContent = "";
        try {
            Elements paragraphs = Jsoup.connect(theStory.getURL()).get().getElementsByClass("bbc-yabuuk e1cc2ql70");
            for(Element paragraph: paragraphs){
                storyContent += paragraph.text();
            }
            theStory.addContent(storyContent);
        } catch (IOException ex) {
            Logger.getLogger(WebScrapper.class.getName()).log(Level.SEVERE, null, ex);
        }
        totalWordsField.setText(""+theStory.getWordsCount());
        totalUniqueWordsField.setText(""+theStory.getTotalUniqueWords());
        ArrayList<Word> mostFrequentWords = theStory.getTop10MostFrequentWords();
        highestWordFrequencyField.setText(""+mostFrequentWords.get(0).getFrequency());
        //PROGRESS BAR # 1
        frequencyValue1.setOrientation(JProgressBar.VERTICAL);
        frequencyValue1.setBackground(Color.WHITE);
        frequencyValue1.setForeground(Color.BLUE);
        frequencyValue1.setValue(mostFrequentWords.get(0).getFrequency());
        frequencyValue1.setString(mostFrequentWords.get(0).getWord());
        frequencyValue1.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        //PROGRESS BAR # 2
        frequencyValue2.setOrientation(JProgressBar.VERTICAL);
        frequencyValue2.setBackground(Color.WHITE);
        frequencyValue2.setForeground(Color.BLUE);
        frequencyValue2.setValue(mostFrequentWords.get(1).getFrequency());
        frequencyValue2.setString(mostFrequentWords.get(1).getWord());
        frequencyValue2.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        //PROGRESS BAR # 3
        frequencyValue3.setOrientation(JProgressBar.VERTICAL);
        frequencyValue3.setBackground(Color.WHITE);
        frequencyValue3.setForeground(Color.BLUE);
        frequencyValue3.setValue(mostFrequentWords.get(2).getFrequency());
        frequencyValue3.setString(mostFrequentWords.get(2).getWord());
        frequencyValue3.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        //PROGRESS BAR # 4
        frequencyValue4.setOrientation(JProgressBar.VERTICAL);
        frequencyValue4.setBackground(Color.WHITE);
        frequencyValue4.setForeground(Color.BLUE);
        frequencyValue4.setValue(mostFrequentWords.get(3).getFrequency());
        frequencyValue4.setString(mostFrequentWords.get(3).getWord());
        frequencyValue4.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        //PROGRESS BAR # 5
        frequencyValue5.setOrientation(JProgressBar.VERTICAL);
        frequencyValue5.setBackground(Color.WHITE);
        frequencyValue5.setForeground(Color.BLUE);
        frequencyValue5.setValue(mostFrequentWords.get(4).getFrequency());
        frequencyValue5.setString(mostFrequentWords.get(4).getWord());
        frequencyValue5.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        //PROGRESS BAR # 6
        frequencyValue6.setOrientation(JProgressBar.VERTICAL);
        frequencyValue6.setBackground(Color.WHITE);
        frequencyValue6.setForeground(Color.BLUE);
        frequencyValue6.setValue(mostFrequentWords.get(5).getFrequency());
        frequencyValue6.setString(mostFrequentWords.get(5).getWord());
        frequencyValue6.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        //PROGRESS BAR # 7
        frequencyValue7.setOrientation(JProgressBar.VERTICAL);
        frequencyValue7.setBackground(Color.WHITE);
        frequencyValue7.setForeground(Color.BLUE);
        frequencyValue7.setValue(mostFrequentWords.get(6).getFrequency());
        frequencyValue7.setString(mostFrequentWords.get(6).getWord());
        frequencyValue7.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        //PROGRESS BAR # 8
        frequencyValue8.setOrientation(JProgressBar.VERTICAL);
        frequencyValue8.setBackground(Color.WHITE);
        frequencyValue8.setForeground(Color.BLUE);
        frequencyValue8.setValue(mostFrequentWords.get(7).getFrequency());
        frequencyValue8.setString(mostFrequentWords.get(7).getWord());
        frequencyValue8.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        //PROGRESS BAR # 9
        frequencyValue9.setOrientation(JProgressBar.VERTICAL);
        frequencyValue9.setBackground(Color.WHITE);
        frequencyValue9.setForeground(Color.BLUE);
        frequencyValue9.setValue(mostFrequentWords.get(8).getFrequency());
        frequencyValue9.setString(mostFrequentWords.get(8).getWord());
        frequencyValue9.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        //PROGRESS BAR # 10
        frequencyValue10.setOrientation(JProgressBar.VERTICAL);
        frequencyValue10.setBackground(Color.WHITE);
        frequencyValue10.setForeground(Color.BLUE);
        frequencyValue10.setValue(mostFrequentWords.get(9).getFrequency());
        frequencyValue10.setString(mostFrequentWords.get(9).getWord()+"("+mostFrequentWords.get(9).getFrequency()+")");
        frequencyValue10.setUI(new BasicProgressBarUI() {
            protected Color getSelectionBackground(){return Color.black;}
            protected Color getSelectionForeground(){return Color.white;}
        });
        
    }//GEN-LAST:event_storyComboBoxActionPerformed

    private void webURLTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_webURLTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_webURLTextFieldActionPerformed

    private void categoryComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_categoryComboBoxActionPerformed
        String categoryName = ((String)categoryComboBox.getSelectedItem());
        if(categoryComboBox.getSelectedIndex()==0){
            storyComboBox.setModel(new DefaultComboBoxModel(new String[]{"Select Story"}));
            return;
        }
        String[] storyHeadlines = null;
        for(Category category: categories){
            if(category.getName().equals(categoryName)){
                storyHeadlines = new String[category.getStories().size()+3];
                int i=0;
                storyHeadlines[i++] = "Select Story";
                storyHeadlines[i++] = "Get Shortest Story";
                storyHeadlines[i++] = "Get Largest Story";
                for(Story story: category.getStories()){
                    storyHeadlines[i++] = story.getHeadline();
                }
                storyComboBox.setModel(new DefaultComboBoxModel(storyHeadlines));
                i=0;
                break;
            }
        }
    }//GEN-LAST:event_categoryComboBoxActionPerformed

    private void totalUniqueWordsFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalUniqueWordsFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalUniqueWordsFieldActionPerformed

    private void totalWordsFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalWordsFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_totalWordsFieldActionPerformed

    private void highestWordFrequencyFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_highestWordFrequencyFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_highestWordFrequencyFieldActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new WebScrapper().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> categoryComboBox;
    private javax.swing.JProgressBar frequencyValue1;
    private javax.swing.JProgressBar frequencyValue10;
    private javax.swing.JProgressBar frequencyValue2;
    private javax.swing.JProgressBar frequencyValue3;
    private javax.swing.JProgressBar frequencyValue4;
    private javax.swing.JProgressBar frequencyValue5;
    private javax.swing.JProgressBar frequencyValue6;
    private javax.swing.JProgressBar frequencyValue7;
    private javax.swing.JProgressBar frequencyValue8;
    private javax.swing.JProgressBar frequencyValue9;
    private javax.swing.JTextField highestWordFrequencyField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTabbedPane resultsTab;
    private javax.swing.JButton scrapButton;
    private javax.swing.JComboBox<String> storyComboBox;
    private javax.swing.JTextField totalUniqueWordsField;
    private javax.swing.JTextField totalWordsField;
    private javax.swing.JTextField webURLTextField;
    // End of variables declaration//GEN-END:variables
}
