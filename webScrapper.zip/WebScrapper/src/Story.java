import java.util.ArrayList;

public class Story {
    private String headline;
    private String URL;
    private String content;
    private ArrayList<Word> words = new ArrayList<Word>();
    
    public Story(String headline, String URL){
        this.headline = headline;
        this.URL = URL;
    }

    public String getHeadline() {
        return headline;
    }

    public String getURL() {
        return URL;
    }

    public String getContent() {
        return content;
    }
    
    public void addContent(String storyContent){
        this.words = new ArrayList<Word>();
        this.content = storyContent;
        storyContent = storyContent.replaceAll("\\p{Punct}", ""); //This removes english punctuations
        for(String word: storyContent.split(" ")){
            for(char c: (new String(word)).toCharArray()){
                switch(""+c){
                    case "\u06A9":
                    case "\u06AF":
                    case "\u06BA":
                    case "\u06BE":
                    case "\u06C1":
                    case "\u06CC":
                    case "\u06D2":
                    case "\u062A":
                    case "\u062B":
                    case "\u062C":
                    case "\u062D":
                    case "\u062E":
                    case "\u062F":
                    case "\u063A":
                    case "\u067E":
                    case "\u0621":
                    case "\u0622":
                    case "\u0624":
                    case "\u0626":
                    case "\u0627":
                    case "\u0628":
                    case "\u0630":
                    case "\u0631":
                    case "\u0632":
                    case "\u0633":
                    case "\u0634":
                    case "\u0635":
                    case "\u0636":
                    case "\u0637":
                    case "\u0638":
                    case "\u0639":
                    case "\u0640":
                    case "\u0641":
                    case "\u0642":
                    case "\u0644":
                    case "\u0645":
                    case "\u0646":
                    case "\u0648":
                    case "\u0679":
                    case "\u0686":
                    case "\u0688":
                    case "\u0691":
                    case "\u0698":
                        break;
                    default:
                        word = word.replaceAll(""+c, "");
                        break;
                }
            }
            if(word.length() > 0) {
                addWord(word);
            }
        }
    }
    
    public Integer getWordsCount(){
        int totalWords = 0;
        for(Word word: words){
            totalWords += word.getFrequency();
        }
        return totalWords;
    }
    
    public void addWord(String newWord){
        for(Word word: words){
            if(newWord.equalsIgnoreCase(word.getWord())){
                word.increaseFrequency();
                return;
            }
        }
        words.add(new Word(newWord));
    }
    
    public ArrayList<Word> getWords(){
        return words;
    }

    public int getTotalUniqueWords(){
        return words.size();
    }

    public ArrayList<Word> getTop10MostFrequentWords(){
        sort();
        ArrayList mostFrequentWords = new ArrayList<Word>();
        for(int i=words.size()-1; i>words.size()-11; i--){
            mostFrequentWords.add(words.get(i));
        }
        return mostFrequentWords;
    }
    
    private void sort(){
        Object[] unsortedWords = words.toArray();
        for(int i=0; i<unsortedWords.length; i++){
            for(int j=i+1; j<unsortedWords.length; j++){
                if(((Word)unsortedWords[i]).getFrequency() > ((Word)unsortedWords[j]).getFrequency()){
                    Word temporary = ((Word)unsortedWords[i]);
                    unsortedWords[i] = ((Word)unsortedWords[j]);
                    unsortedWords[j] = ((Word)temporary);
                }
            }
        }
        words = new ArrayList<Word>();
        for(Object word: unsortedWords){
            words.add((Word)word);
        }
    }
}
