public class Word {
    private String word;
    private Integer frequency=0;
    
    public Word(String word){
        this.word = word;
        this.frequency=1;
    }
    
    public String getWord(){
        return (this.word);
    }
    
    public Integer getFrequency(){
        return (this.frequency);
    }
    
    public Integer increaseFrequency(){
        return (++frequency);
    }
    
    public String toString(){
        return (""+word+"("+frequency+")");
    }
}
