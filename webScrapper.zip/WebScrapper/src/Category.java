import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Category {
    private String name;
    private String URL;
    private ArrayList<Story> stories = stories = new ArrayList<Story>();
    private int totalStoryCount;
    
    
    public Category(String name, String URL){
        this.name = name;
        this.URL = URL;
    }

    public String getName() {
        return name;
    }

    public String getURL() {
        return URL;
    }

    public void addStory(Story story){
        stories.add(story);
    }

    public int getTotalStoryCount() {
        return (stories.size());
    }
    
    public Story getMaxStory(){
        Story maxStory = stories.get(0);
        for(Story story: stories){
            if(maxStory.getWordsCount() < story.getWordsCount()){
                maxStory = story;
            }
        }
        return (maxStory);
    }
    
    public Story getMinStory(){
        Story minStory = stories.get(0);
        for(Story story: stories){
            if(minStory.getWordsCount() > story.getWordsCount()){
                minStory = story;
            }
        }
        return (minStory);
    }
    
    public void addToCSVFile(String filename, Category category) throws IOException{
        FileWriter fileWriter = new FileWriter(filename);
        for(Story story: stories){
            fileWriter.write(name+", "+story.getHeadline()+", "+story.getContent()+"\n");
        }
        fileWriter.close();
    }
    
    public ArrayList<Story> getStories(){
        return stories;
    }
}
